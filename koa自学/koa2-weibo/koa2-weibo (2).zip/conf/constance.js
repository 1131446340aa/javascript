module.exports = {
    SECRIET: 'UsdU*dqwdqwdqwd161dqw31d3q2156d1wq'
}  