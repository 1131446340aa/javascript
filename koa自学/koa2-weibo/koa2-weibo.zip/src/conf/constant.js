const DEFAULT_PICTURE='https://dss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1712216034,2924212808&fm=111&gp=0.jpg'
module.exports={
    DEFAULT_PICTURE
}