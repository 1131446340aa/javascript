module.exports={
    CRYPTO_SECRET_KEY:'fewfrwugfbiwufe2w115156*--//@'
}