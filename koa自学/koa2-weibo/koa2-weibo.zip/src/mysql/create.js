// const { Blog, User } = require ('./module.js')
// !(async ()=>{
//     const zhangsan =await User.create({
//         userName:'15079482413',
//         nickName:'zhangsan',
//         passWord:'113144'
//     })
//     const lisi =await User.create({
//         userName:'1131446340',
//         nickName:'lisi',
//         passWord:'113144'
//     })
    
//     const blog1 = await Blog.create({
//         title:'标题1',
//         content:'内容1',
//         userId:8
//     }) 
// })() 