// const { Blog, User } = require('./module.js')

// !(async () => {
//     const zhangsan = await User.destroy({
//         where: {
//             userName: '15079482413'
//         }
//     })

// })() 