// const { Blog, User } = require('./module.js')

// !(async () => {
//     const zhangsan = await User.findOne({
//         where: {
//             userName: '15079482413'
//         }
//     })

//     const zhangsanBlogList = await Blog.findAll({
//         where: {
//             userId: '8'
//         }
//     })
//     console.log(zhangsanBlogList.map(blog => blog.dataValues))

// })() 