const sequelize = require('sequelize')

const STRING = sequelize.STRING

const DECIMAL =sequelize.DECIMAL
const TEXT = sequelize.TEXT
const INTEGER = sequelize.INTEGER
const BOOLEAN =sequelize.BOOLEAN
module.exports = { STRING,DECIMAL ,TEXT ,INTEGER ,BOOLEAN}