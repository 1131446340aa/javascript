// const { Blog, User } = require('./module.js')
// !(async () => {
//     const upDateuser = await User.update({
//         nickName: '张三'
//     },
//     {
//         where: {
//             userName: '15079482413'
//         }
//     })
// })() 