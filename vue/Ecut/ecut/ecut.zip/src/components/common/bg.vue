<template>
  <div class="bg"></div>
</template>

<script>
export default {

}
</script>
<style lang="stylus" scoped>
.bg
  position fixed
  top 0
  left 0
  bottom 0
  right 0
  z-index -1
  background-color rgba(229, 229, 229, 0.3)
</style>