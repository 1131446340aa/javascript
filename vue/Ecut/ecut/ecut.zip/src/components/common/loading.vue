<template>
  <div class="main"></div>
</template>

<script>
export default {

}
</script>

<style lang="stylus" scoped>
.main
  position fixed
  top 50%
  left 50%
  transform translate(-50%,-50%)
</style>