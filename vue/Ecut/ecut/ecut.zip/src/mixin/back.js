export default {
    methods: {
        back() {
            this.$router.go(-1)
        }
    }
}